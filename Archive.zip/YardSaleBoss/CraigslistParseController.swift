//
//  CraigslistParser.swift
//  YardSaleBoss
//
//  Created by Jeremiah Hawks on 3/30/17.
//  Copyright © 2017 Jeremiah Hawks. All rights reserved.
//

import Foundation
import HTMLReader

//class CraigslistParseController {
//    
//    
//    func getUSElementFrom(htmlDoc: HTMLDocument) -> HTMLElement? {
//        let stateClassElement = htmlDoc.firstNode(matchingSelector: "div[class^='colmask']")
//        return stateClassElement
//    }
//    
//    func parseUSElement(USElement: HTMLElement) -> ([String: HTMLElement]) {
//        var element = USElement
//        let boxElements = element.nodes(matchingSelector: "div[class^='box']")
////        while USElement.nodes(matchingSelector: "div[class^='box']")[0].attributes.description.contains("h4") {
////            let stateName = element.firstNode(matchingSelector: "div[class^='box']")?.attributes
////        }
//    }
//    
//    func parseRegionElement(regionElement: HTMLElement) -> CraigslistRegion {
//        
//    }
//}
