//
//  CraigslistRegion.swift
//  YardSaleBoss
//
//  Created by Jeremiah Hawks on 3/30/17.
//  Copyright © 2017 Jeremiah Hawks. All rights reserved.
//

import Foundation
import HTMLReader

//class CraigslistRegion {
//    let name: String
//    let baseAddress: String
//    
//    init(name: String, baseAddress: String) {
//        self.name = name
//        self.baseAddress = baseAddress
//    }
//    
//    convenience init(htmlElement: HTMLElement) {
//        
//    }
//}
