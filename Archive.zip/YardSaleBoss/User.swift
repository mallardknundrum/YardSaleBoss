//
//  User.swift
//  YardSaleBoss
//
//  Created by Jeremiah Hawks on 3/17/17.
//  Copyright © 2017 Jeremiah Hawks. All rights reserved.
//

import Foundation
import CloudKit
import CoreData

class User {
    static var startAddress = ""
    static var endAddress = ""
    static var savedYardsaleIDs: [String] = []
    static var showTutorial = true
}


