//
//  CraigslistState.swift
//  YardSaleBoss
//
//  Created by Jeremiah Hawks on 3/30/17.
//  Copyright © 2017 Jeremiah Hawks. All rights reserved.
//

import Foundation
import HTMLReader


//class CraigslistState {
//    let name: String
//    let regions: [CraigslistRegion] = []
//    
//    init(htmlElement: HTMLElement)
//}
